package reidsss.reidsss;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

public class StringTokenizerDemo3 {

	public static void main(String[] args) {

		String a = ";1;34343.00;3444.00;5555;8888;9999.000;hstom;afasjflafjajafj";

		List<String> strss = new ArrayList<>();
		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < 3000000; i++) {
			strss.add(i + a);
		}

		long begin = System.currentTimeMillis();
		long vv = 0;
		List<TestvO> list = new ArrayList<>(strss.size());

		TestvO current = new TestvO();

		Iterator<String> iter = strss.parallelStream().iterator();
		for (int i = 0; iter.hasNext(); i++) {

			long begin2 = System.currentTimeMillis();
			StringTokenizer st = new StringTokenizer(iter.next(), ";");
			long begin3 = System.currentTimeMillis();
			vv += begin3 - begin2;
			for (int j = 0; st.hasMoreTokens(); j++) {

				String value = st.nextToken();
				if (j == 0) {
					setValue(current, j, value);
				} else {
					if (j == 0 || j == 7 || j == 8) {
						continue;
					}
					setValue2(current, j, value);
				}

			}

			if ((i + 1) % 100 == 0) {
				// System.out.println(current.getIp());
				caacl(current);

				list.add(current);
				current = new TestvO();
			}

		}

		long end = System.currentTimeMillis();
		System.out.println((end - begin) + "==" + list.size());

		System.out.println(vv);
	}

	private static void caacl(TestvO current) {

		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));
		current.setCaps(Math.round(current.getCaps() / current.getQuest()));

	}

	private static void setValue(TestvO vo, int i, String value) {
		switch (i) {
		case 0: {

			vo.setIp(Long.valueOf(value));
			return;

		}
		case 1: {
			vo.setInterfaceId(Integer.valueOf(value));
			return;
		}
		case 2: {
			vo.setCaps(Double.valueOf(value));
			return;
		}
		case 3: {
			vo.setQuest(Double.valueOf(value));
			return;
		}
		case 4: {
			vo.setTcaps(Double.valueOf(value));
			return;
		}
		case 5: {
			vo.setSucReest(Double.valueOf(value));
			return;
		}
		case 6: {
			vo.setTtool(Double.valueOf(value));
			return;
		}
		case 7: {
			vo.setHostname(value);
			return;
		}
		case 8: {
			vo.setItemName(value);
		}
		}
	}

	private static void setValue2(TestvO vo, int i, String value) {
		switch (i) {

		case 2: {

			vo.setCaps(vo.getCaps() + Double.valueOf(value));
			return;
		}
		case 3: {
			vo.setQuest(vo.getQuest() + Double.valueOf(value));
			return;
		}
		case 4: {
			vo.setTcaps(vo.getTcaps() + Double.valueOf(value));
			return;
		}
		case 5: {
			vo.setSucReest(vo.getSucReest() + Double.valueOf(value));
			return;
		}
		case 6: {
			vo.setTtool(vo.getTtool() + Double.valueOf(value));
			return;
		}

		}
	}

}